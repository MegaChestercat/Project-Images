# Animal > 2023-11-20 12:27am
https://universe.roboflow.com/artificial-vision-8cjrr/animal-ugehs

Provided by a Roboflow user
License: CC BY 4.0

